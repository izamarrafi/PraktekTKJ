<?php
include "koneksi.php";

// --- PROSES TAMBAH DATA ---
if (isset($_POST['create'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $nis  = mysqli_real_escape_string($conn, $_POST['nis']);
    $jk   = mysqli_real_escape_string($conn, $_POST['jk']);
    
    mysqli_query($conn, "INSERT INTO tb_anggota (nama, nis, jk) VALUES ('$nama','$nis','$jk')");
    echo "<script>window.location='data_anggota.php';</script>";
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['update'])) {
    $id   = mysqli_real_escape_string($conn, $_POST['id']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $nis  = mysqli_real_escape_string($conn, $_POST['nis']);
    $jk   = mysqli_real_escape_string($conn, $_POST['jk']);

    mysqli_query($conn, "UPDATE tb_anggota SET nama='$nama', nis='$nis', jk='$jk' WHERE id='$id'");
    echo "<script>alert('Data anggota berhasil diperbarui.');</script>";
    echo "<script>window.location='data_anggota.php';</script>";
}

// --- PROSES HAPUS DATA ---
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    $cek_anggota = mysqli_query($conn, "SELECT * FROM tb_peminjaman WHERE id_anggota = '$id'");

    if (mysqli_num_rows($cek_anggota) > 0) {
        echo "<script>
                alert('Anggota ini masih terdaftar dalam data peminjaman.');
                window.location='data_anggota.php';
              </script>";
    } else {
        $query = mysqli_query($conn, "DELETE FROM tb_anggota WHERE id='$id'");
        if($query) {
            echo "<script>alert('Data anggota berhasil dihapus.'); window.location='data_anggota.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    
    <meta charset="UTF-8">
    <title>👥 Data Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { margin:0; font-family:'Poppins',sans-serif; background:#f4f6f9; }
        .sidebar { width:250px; height:100vh; position:fixed; background:#1e293b; color:white; padding:20px; }
        .sidebar a { display:block; color:#cbd5f5; padding:10px; border-radius:10px; text-decoration:none; margin-bottom:5px; }
        .sidebar a:hover { background:#334155; color:white; }
        .profile-img { width:80px; height:80px; border-radius:50%; object-fit:cover; border:3px solid #4f46e5; }
        .main { margin-left:260px; padding:20px; }
        .card { border-radius:15px; box-shadow:0 4px 10px rgba(0,0,0,0.05); }
        .table thead { background:#6366f1; color:white; }
        .logout-btn { color: #ff6b6b !important; margin-top: auto; font-weight: bold; border-top: 1px solid #334155; padding-top: 15px !important; }
        .logout-btn:hover { background: #452a2a !important; color: #ff8e8e !important; }
        /* PERBAIKAN CSS SEARCH */
        .search-group {
            position: relative;
            width: 250px;
        }
        .search-group i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            z-index: 10;
        }
        .search-group .form-control {
            padding-left: 35px; /* Memberi ruang agar teks tidak menabrak ikon */
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h4><i class="fa fa-book"></i> E Library</h4>
    <div class="text-center mb-3">
        <img src="perpus.jpeg" class="profile-img">
    </div>
    <a href="dashboard.php"><i class="fa-solid fa-house me-2"></i> Dashboard</a>
    <a href="data_buku.php"><i class="fa-solid fa-book me-2"></i> Data Buku</a>
    <a href="data_anggota.php" style="background:#334155;"><i class="fa-solid fa-users me-2"></i> Anggota</a>
    <a href="data_peminjaman.php"><i class="fa-solid fa-book-open me-2"></i> Peminjaman</a>
    <a href="data_pengembalian.php"><i class="fa-solid fa-square-check me-2"></i> Pengembalian</a>
    
   <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
        <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
    </a>
</div>
</div>

<div class="main">
    <h3>👥 Data Anggota</h3>
    
    <div class="card mb-3">
        <div class="card-body">
            <form method="POST" class="row g-2">
                <div class="col-md-4"><input class="form-control" name="nama" placeholder="Nama Lengkap" required></div>
                <div class="col-md-3"><input class="form-control" name="nis" placeholder="NIS" required></div>
                <div class="col-md-3">
                    <select class="form-control" name="jk" required>
                        <option value="">-- Pilih JK --</option>
                        <option value="laki laki">Laki-laki</option>
                        <option value="perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="col-md-2"><button class="btn btn-primary w-100" name="create"><i class="fa fa-plus"></i> Tambah</button></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-white pt-3 pb-3 border-0 d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Daftar Anggota</h5>
            <div class="search-group">
                <i class="fa fa-search"></i>
                <input type="text" class="form-control" placeholder="Cari data anggota..." id="searchInput">
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>NIS</th>
                        <th>JK</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $q = mysqli_query($conn, "SELECT * FROM tb_anggota ORDER BY id DESC"); 
                    while($d = mysqli_fetch_assoc($q)){ 
                    ?>
                    <tr>
                        <td><?= $d['id'] ?></td>
                        <td><?= $d['nama'] ?></td>
                        <td><?= $d['nis'] ?></td>
                        <td><?= ucfirst($d['jk']) ?></td>
                        <td class="text-center">
                            <button class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#edit<?= $d['id'] ?>">
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <a href="?delete=<?= $d['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">
                                <i class="fa fa-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>

                    <div class="modal fade" id="edit<?= $d['id'] ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Ubah Data Anggota</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $d['id'] ?>">
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Nama Lengkap</label>
                                            <input type="text" name="nama" class="form-control" value="<?= $d['nama'] ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">NIS</label>
                                            <input type="text" name="nis" class="form-control" value="<?= $d['nis'] ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Jenis Kelamin</label>
                                            <select name="jk" class="form-control" required>
                                                <option value="laki laki" <?= $d['jk'] == 'laki laki' ? 'selected' : '' ?>>Laki-laki</option>
                                                <option value="perempuan" <?= $d['jk'] == 'perempuan' ? 'selected' : '' ?>>Perempuan</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Fitur Search Real-time
    document.getElementById('searchInput').addEventListener('input', function() {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll('.table tbody tr'); // Pastikan selector benar

        rows.forEach(row => {
            let text = row.innerText.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
</script>
</body>
</html>