<?php
include "koneksi.php";

// --- PROSES HAPUS RIWAYAT ---
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    mysqli_query($conn, "DELETE FROM tb_pengembalian WHERE id='$id'");
    echo "<script>alert('Data riwayat berhasil dihapus.'); window.location='data_pengembalian.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Pengembalian Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { margin: 0; font-family: 'Poppins', sans-serif; background: #f4f6f9; }
        .sidebar { width: 250px; height: 100vh; position: fixed; background: #1e293b; color: white; padding: 20px; z-index: 1000; }
        .sidebar a { display: block; color: #cbd5f5; padding: 10px; border-radius: 10px; text-decoration: none; margin-bottom: 5px; }
        .sidebar a:hover { background: #334155; color: white; }
        .profile-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #10b981; }
        .main { margin-left: 250px; padding: 30px; min-height: 100vh; }
        .card { border-radius: 15px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); border: none; }
        .table thead { background: #10b981; color: white; }
        .logout-btn { color: #ff6b6b !important; margin-top: auto; font-weight: bold; border-top: 1px solid #334155; padding-top: 15px !important; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h4><i class="fa fa-book"></i> E Library</h4>
        <div class="text-center mb-3">
            <img src="perpus.jpeg" class="profile-img" alt="Profile">
        </div>
        <a href="dashboard.php"><i class="fa-solid fa-house me-2"></i> Dashboard</a>
        <a href="data_buku.php"><i class="fa-solid fa-book me-2"></i> Data Buku</a>
        <a href="data_anggota.php"><i class="fa-solid fa-users me-2"></i> Anggota</a>
        <a href="data_peminjaman.php"><i class="fa-solid fa-book-open me-2"></i> Peminjaman</a>
        <a href="data_pengembalian.php" style="background:#334155;"><i class="fa-solid fa-square-check me-2"></i> Pengembalian</a>
        <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
            <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
        </a>
    </div>

    <div class="main">
        <h3>✅ Riwayat Pengembalian</h3>

        <div class="card">
            <div class="card-header bg-white pt-3 pb-0 border-0">
                <h5 class="mb-0">Daftar Log Riwayat</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="returnTable">
                        <thead>
                            <tr>
                                <th>Anggota</th>
                                <th>Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Batas Kembali</th>
                                <th>Tgl Dikembalikan</th> <th>Status</th>
                                <th>Denda</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $q = mysqli_query($conn, "SELECT * FROM tb_pengembalian ORDER BY id DESC");
                            while ($d = mysqli_fetch_assoc($q)) {
                            ?>
                                <tr>
                                    <td><b><?= htmlspecialchars($d['nama']) ?></b></td>
                                    <td><?= htmlspecialchars($d['judul']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($d['tanggal_pinjam'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($d['tanggal_kembali'])) ?></td>
                                    
                                    <td>
                                        <span class="text-primary fw-bold">
                                            <?php 
                                            if ($d['denda'] > 0) {
                                                // Jika denda di atas 0, tampilkan estimasi hari telat dari denda kotornya
                                                $hari_telat = $d['denda'] / 1000;
                                                echo date('d/m/Y', strtotime("+$hari_telat days", strtotime($d['tanggal_kembali'])));
                                            } else {
                                                echo date('d/m/Y', strtotime($d['tanggal_kembali']));
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    
                                    <td><span class="badge bg-success"><?= htmlspecialchars($d['status']) ?></span></td>
                                    <td>
                                        <?php if ($d['denda'] > 0): ?>
                                            <span class="text-danger fw-bold">Rp <?= number_format($d['denda'], 0, ',', '.') ?></span>
                                        <?php else: ?>
                                            <span class="text-secondary">0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="?delete=<?= $d['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus riwayat ini?')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>