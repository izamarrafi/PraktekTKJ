<?php
session_start();
// Pastikan kamu sudah membuat file koneksi.php
include 'koneksi.php'; 

if (isset($_POST['login'])) {
    // Mengambil input dan melindunginya dari SQL Injection
    $user_input = mysqli_real_escape_string($conn, $_POST['username']);
    $pass_input = mysqli_real_escape_string($conn, $_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$user_input' AND password='$pass_input'");
    

    if (mysqli_num_rows($query) > 0) {
        $data = mysqli_fetch_assoc($query);

    
        $_SESSION['username'] = $data['username'];
        $_SESSION['role']     = $data['role'];

        if ($data['role'] == 'admin') {
            header("Location: dashboard.php");
        } else {
            header("Location: dashboardUser.php");
        }
        exit();
    } else {
        // Jika tidak ditemukan, balik ke index dengan pesan gagal
        header("Location: login.php?pesan=gagal");
        exit();
    }
}
?>