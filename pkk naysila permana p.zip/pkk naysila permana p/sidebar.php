<div class="sidebar">
    <h4><i class="fa fa-book"></i> E Library</h4>
    <div class="text-center mb-3">
        <img src="fotoNay.jpeg" class="profile-img">
        <p class="mt-2"><b>Naysila</b><br><small>Administrator</small></p>
    </div>
    
    <a href="konten_dashboard.php" target="konten">🏠 Dashboard</a>
    <a href="data_buku.php" target="konten">📚 Data Buku</a>
    <a href="data_anggota.php" target="konten">👥 Anggota</a>
    <a href="data_peminjaman.php" target="konten">📖 Peminjaman</a>
    <a href="data_pengembalian.php" target="konten">✅ Pengembalian</a>
</div>

<div class="main" style="padding: 0;">
    <iframe src="konten_dashboard.php" name="konten" frameborder="0" style="width: 100%; height: 100vh;"></iframe>
</div>