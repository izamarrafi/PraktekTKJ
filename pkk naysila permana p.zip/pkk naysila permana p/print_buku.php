<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Data Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding: 30px; 
            background: white;
        }
        .header-print { 
            text-align: center; 
            margin-bottom: 30px; 
            border-bottom: 2px solid #000; 
            padding-bottom: 10px; 
        }
        /* Tabel Polos & Bersih */
        .table {
            border: 1px solid #000 !important;
        }
        .table th {
            background-color: #f8f9fa !important;
            border: 1px solid #000 !important;
            text-align: center;
        }
        .table td {
            border: 1px solid #000 !important;
        }
        
        /* Mengatur posisi konten bawah ke kanan */
        .footer-section {
            display: flex;
            flex-direction: column;
            align-items: flex-end; 
            margin-top: 30px;
        }
        .ttd {
            text-align: center;
            width: 250px;
        }
        .ttd-space {
            height: 80px;
        }

        /* Hilangkan header dan footer bawaan browser */
        @media print {
            @page { 
                margin: 0; 
            }
            body { 
                padding: 1.5cm; 
            }
            .no-print { 
                display: none !important; 
            }
        }
    </style>
</head>
<body>

    <div class="header-print">
        <h2 class="mb-1">E-LIBRARY NAYSILA</h2>
        <p class="mb-0">Laporan Data Koleksi Buku Perpustakaan</p>
        <small>Tanggal Cetak: <?php echo date('d-m-Y'); ?></small>
    </div>

    <table class="table table-bordered align-middle">
        <thead>
            <tr>
                <th width="50">No</th>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th>Penerbit</th>
                <th width="80">Tahun</th>
                <th width="80">Jumlah</th>
                <th>Lokasi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $sql = mysqli_query($conn, "SELECT * FROM tb_buku ORDER BY judul ASC");
            
            while($data = mysqli_fetch_array($sql)) {
            ?>
                <tr>
                    <td class="text-center"><?php echo $no++; ?></td>
                    <td><?php echo $data['judul']; ?></td>
                    <td><?php echo $data['pengarang']; ?></td>
                    <td><?php echo $data['penerbit']; ?></td>
                    <td class="text-center"><?php echo $data['tahun_terbit']; ?></td>
                    <td class="text-center"><?php echo $data['jumlah_buku']; ?></td>
                    <td class="text-center"><?php echo $data['lokasi']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="footer-section">
        <div class="ttd">
            <p class="mb-0">Batujajar, <?php echo date('d-m-Y'); ?></p>
            <p class="mb-0">Petugas Perpustakaan,</p>
            <div class="ttd-space"></div>
            <p class="fw-bold mb-0">( Naysila )</p>
        </div>

        <div class="no-print mt-3 text-end">
            <button onclick="window.print()" class="btn btn-primary">Cetak Laporan</button>
            <button onclick="window.close()" class="btn btn-danger">Tutup</button>
        </div>
    </div>

    <script>
        // Otomatis muncul dialog print
        window.print();
    </script>

</body>
</html>