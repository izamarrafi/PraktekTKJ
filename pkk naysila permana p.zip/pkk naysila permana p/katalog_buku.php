<?php
include "koneksi.php";
session_start();

// MENCEGAH ERROR UNDEFINED: Jika session login belum ada / kosong, isi dengan data default sementara untuk uji coba
$id_user   = isset($_SESSION['id_user']) ? $_SESSION['id_user'] : '1'; 
$nama_user = isset($_SESSION['nama']) ? $_SESSION['nama'] : 'Naysila'; 
$role_user = isset($_SESSION['role']) ? $_SESSION['role'] : 'User';

$semua_buku = [
    'Teknologi' => [
        ['judul' => 'Belajar JavaScript', 'foto' => 'https://www.w3schools.com/whatis/img_js.png'],
    ],
    'Sains' => [
        ['judul' => 'Fisika Kuantum', 'foto' => 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400'],
        ['judul' => 'Astronomi Dasar', 'foto' => 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400']
    ],
    'Novel' => [
        ['judul' => 'Laskar Pelangi', 'foto' => 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400'],
        ['judul' => 'Bumi Manusia', 'foto' => 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400']
    ],
    'Sejarah' => [
        ['judul' => 'Sejarah Dunia', 'foto' => 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=400']
    ]
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-LIBRARY NAYSILA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        
        /* Navbar Biru Gelap Panjang Atas (Sesuai image_fb39e7.png) */
        .top-navbar {
            background: #2c3e50;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar-title { font-size: 24px; font-weight: bold; display: flex; align-items: center; gap: 10px; }
        .btn-logout-top { background: #e74c3c; color: white; border: none; border-radius: 8px; padding: 8px 16px; font-weight: bold; }
        .btn-logout-top:hover { background: #c0392b; color: white; }

        /* Form Baris Kotak Putih Atas (Sesuai image_fb39e7.png) */
        .card-peminjaman-aktif { border-radius: 15px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .form-inline-custom { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .form-inline-custom .form-control, .form-inline-custom .form-select { width: auto; min-width: 140px; border-radius: 8px; background-color: #ffffff; }

        /* Kategori Sebelah Kiri */
        .category-item { padding: 12px 20px; color: #333; text-decoration: none; display: block; border-radius: 8px; margin-bottom: 8px; background: #fff; transition: 0.2s; border: 1px solid #e2e8f0; }
        .category-item:hover, .category-item.active { background: #007bff; color: white; border-color: #007bff; font-weight: bold; }

        /* Kotak Buku / Cover Buku Tengah */
        .book-card { border: none; border-radius: 15px; background: #fff; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .book-img-container { height: 220px; display: flex; justify-content: center; align-items: center; background: #ffffff; padding: 15px; }
        .book-img { max-height: 100%; max-width: 100%; object-fit: contain; }
        .btn-pilih-buku { border-radius: 8px; border: 1px solid #007bff; color: #007bff; background: transparent; width: 100%; font-weight: 500; transition: 0.3s; padding: 6px; text-decoration: none; display: inline-block; }
        .btn-pilih-buku:hover { background: #007bff; color: white; }

        /* Tabel Riwayat Panjang Bawah (Sesuai image_fad447.png) */
        .card-history { border-radius: 15px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .table thead { background: #212529; color: white; }
        .badge-status { border-radius: 6px; padding: 6px 12px; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>

    <div class="top-navbar">
        <div class="navbar-title">
            📚 E-LIBRARY <?= strtoupper(htmlspecialchars($nama_user)) ?>
        </div>
        <a href="logout.php" class="btn btn-logout-top" onclick="return confirm('Apakah anda yakin ingin keluar?')">
            <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
        </a>
    </div>

    <div class="container-fluid p-4">
        
        <div class="card card-peminjaman-aktif mb-4">
            <div class="card-body p-4">
                <h5 class="text-primary fw-bold mb-3"><i class="fa-solid fa-book-bookmark me-2"></i> Peminjaman Aktif</h5>
                <form method="POST" action="proses_pinjam.php" class="form-inline-custom">
                    <input type="text" class="form-control" placeholder="ID User" value="<?= htmlspecialchars($id_user) ?>" readonly>
                    <input type="text" class="form-control" placeholder="Nama Peminjam" value="<?= htmlspecialchars($nama_user) ?>" readonly>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($role_user) ?>" readonly style="width: 90px;">
                    
                    <select name="id_buku" class="form-select" style="min-width: 250px;" required>
                        <option value="">-- Pilih Buku --</option>
                        <?php
                        $buku_select = mysqli_query($conn, "SELECT * FROM tb_buku");
                        while ($bs = mysqli_fetch_assoc($buku_select)) {
                            echo "<option value='".$bs['id_buku']."'>".htmlspecialchars($bs['judul'])."</option>";
                        }
                        ?>
                    </select>
                    
                    <input type="text" class="form-control" value="<?= date('d/m/Y') ?>" readonly style="width: 140px;">
                    
                    <button type="submit" name="pinjamkan" class="btn btn-primary px-4 fw-bold">Pinjamkan</button>
                    <button type="button" class="btn btn-success px-4 fw-bold" disabled style="opacity: 0.6;">Kembalikan</button>
                </form>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col-md-3">
                <h5 class="fw-bold mb-3">Kategori</h5>
                <?php $kat_aktif = isset($_GET['kategori']) ? $_GET['kategori'] : 'Teknologi'; ?>
                <a href="?kategori=Teknologi" class="category-item <?= ($kat_aktif == 'Teknologi') ? 'active' : '' ?>">Teknologi</a>
                <a href="?kategori=Sains" class="category-item <?= ($kat_aktif == 'Sains') ? 'active' : '' ?>">Sains</a>
                <a href="?kategori=Novel" class="category-item <?= ($kat_aktif == 'Novel') ? 'active' : '' ?>">Novel</a>
                <a href="?kategori=Sejarah" class="category-item <?= ($kat_aktif == 'Sejarah') ? 'active' : '' ?>">Sejarah</a>
            </div>

<div class="col-md-9">
    <h5 class="fw-bold mb-3">Daftar Buku: <?= htmlspecialchars($kat_aktif) ?></h5>
    <div class="row">
        <?php
        // Cek apakah kategori yang dipilih ada di dalam array $semua_buku
        if (!isset($semua_buku[$kat_aktif]) || empty($semua_buku[$kat_aktif])) {
            echo "<div class='col-12'><p class='text-muted italic bg-white p-4 rounded border'>Belum ada koleksi buku di kategori ini.</p></div>";
        } else {
            // Looping data buku dari array PHP $semua_buku sesuai kategori aktif
            foreach ($semua_buku[$kat_aktif] as $b) {
        ?>
                <div class="col-md-4 mb-4">
                    <div class="card book-card">
                        <div class="book-img-container">
                            <img src="<?= htmlspecialchars($b['foto']) ?>" class="book-img" alt="<?= htmlspecialchars($b['judul']) ?>">
                        </div>
                        <div class="card-body text-center p-3">
                            <h6 class="fw-bold mb-3"><?= htmlspecialchars($b['judul']) ?></h6>
                            <a href="proses_pinjam.php?judul=<?= urlencode($b['judul']) ?>" class="btn btn-pilih-buku">Pilih Buku</a>
                        </div>
                    </div>
                </div>
        <?php 
            } 
        } 
        ?>
    </div>
</div>
        </div>

        <div class="card card-history">
            <div class="card-header bg-white py-3 border-0">
                <h5 class="fw-bold mb-0 text-secondary"><i class="fa-solid fa-list-ol me-2"></i> Riwayat & Data Peminjaman</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="ps-4">ID USER</th>
                                <th>NAMA PEMINJAM</th>
                                <th>ROLE</th>
                                <th>JUDUL BUKU</th>
                                <th>TANGGAL AKSI</th>
                                <th>BATAS KEMBALI</th>
                                <th>DENDA</th>
                                <th class="pe-4">STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Tampilkan data peminjaman aktif milik user saat ini
                            $q_aktif = mysqli_query($conn, "SELECT p.*, b.judul FROM tb_peminjaman p 
                                                            JOIN tb_buku b ON p.id_buku = b.id_buku");
                            while ($row = mysqli_fetch_assoc($q_aktif)) {
                            ?>
                                <tr>
                                    <td class="ps-4"><?= htmlspecialchars($id_user) ?></td>
                                    <td><b><?= htmlspecialchars($nama_user) ?></b></td>
                                    <td><?= htmlspecialchars($role_user) ?></td>
                                    <td><?= htmlspecialchars($row['judul']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                                    <td><span class="text-danger fw-bold"><?= date('d/m/Y', strtotime($row['tanggal_kembali'])) ?></span></td>
                                    <td><span class="text-muted">-</span></td>
                                    <td class="pe-4"><span class="badge bg-warning text-dark badge-status">Dipinjam</span></td>
                                </tr>
                            <?php } ?>

                            <?php
                            // Tampilkan data pengembalian riwayat selesai
                            $q_selesai = mysqli_query($conn, "SELECT * FROM tb_pengembalian WHERE nama = '$nama_user' ORDER BY id DESC");
                            while ($s = mysqli_fetch_assoc($q_selesai)) {
                                $text_denda = ($s['denda'] > 0) ? "text-danger fw-bold" : "text-success";
                                $nominal_denda = ($s['denda'] > 0) ? "Rp " . number_format($s['denda'], 0, ',', '.') : "Bebas Denda";
                            ?>
                                <tr>
                                    <td class="ps-4"><?= htmlspecialchars($id_user) ?></td>
                                    <td><b><?= htmlspecialchars($nama_user) ?></b></td>
                                    <td><?= htmlspecialchars($role_user) ?></td>
                                    <td><?= htmlspecialchars($s['judul']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($s['tanggal_pinjam'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($s['tanggal_kembali'])) ?></td>
                                    <td><span class="<?= $text_denda ?>"><?= $nominal_denda ?></span></td>
                                    <td class="pe-4"><span class="badge bg-success badge-status">Buku Dikembalikan</span></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>