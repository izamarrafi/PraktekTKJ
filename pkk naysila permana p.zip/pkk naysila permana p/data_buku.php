<?php
include "koneksi.php";

// ================= INSERT =================
if (isset($_POST['create'])) {
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $jumlah = $_POST['jumlah_buku'];
    $lokasi = $_POST['lokasi'];

    $query = mysqli_query($conn, "INSERT INTO tb_buku 
(id_buku, judul, pengarang, penerbit, tahun_terbit, jumlah_buku, lokasi) 
VALUES (NULL, '$judul', '$pengarang', '$penerbit', '$tahun', '$jumlah', '$lokasi,')");


    }


// ================= UPDATE =================
if (isset($_POST['update'])) {
    $id = $_POST['id_buku'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $jumlah = $_POST['jumlah_buku'];
    $lokasi = $_POST['lokasi'];

    $query = mysqli_query($conn, "UPDATE tb_buku SET
        judul='$judul',
        pengarang='$pengarang',
        penerbit='$penerbit',
        tahun_terbit='$tahun',
        jumlah_buku='$jumlah',
        lokasi='$lokasi'
        WHERE id_buku='$id'");

    if($query) {
        // MENAMBAHKAN NOTIFIKASI BERHASIL DISINI
        echo "<script>alert('Data berhasil diupdate!'); window.location='data_buku.php';</script>";
    }
}

// ================= DELETE =================
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $cek_peminjaman = mysqli_query($conn, "SELECT * FROM tb_peminjaman WHERE id_buku = '$id'");

    if (mysqli_num_rows($cek_peminjaman) > 0) {
        echo "<script>
                alert('Gagal menghapus! Buku ini masih terdaftar dalam data peminjaman.');
                window.location='data_buku.php';
              </script>";
    } else {
        $query = mysqli_query($conn, "DELETE FROM tb_buku WHERE id_buku='$id'");
        
        if($query) {
            echo "<script>
                    alert('Data buku berhasil dihapus.');
                    window.location='data_buku.php';
                  </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>📚 Data Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body { margin:0; font-family: 'Poppins', sans-serif; background:#f4f6f9; }
        
        /* SIDEBAR */
        .sidebar { width:250px; height:100vh; position:fixed; background:#1e293b; color:white; padding:20px; z-index: 1000; }
        .sidebar a { display:block; color:#cbd5f5; padding:10px; border-radius:10px; text-decoration:none; margin-bottom:5px; }
        .sidebar a:hover { background:#334155; color:white; }
        .profile-img { width:80px; height:80px; border-radius:50%; object-fit:cover; border:3px solid #4f46e5; }
        
        /* MAIN CONTENT */
        .main { margin-left:250px; padding:30px; min-height: 100vh; }
        
        .card { border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border: none; }
        .btn-tambah { background: #6366f1; color: white; border-radius: 8px; }
        .btn-edit { background: #0ea5e9; color: white; border-radius: 8px; }
        .btn-hapus { background: #ef4444; color: white; border-radius: 8px; }
        .table thead { background: #6366f1; color: white; }
        .logout-btn { color: #ff6b6b !important; margin-top: auto; font-weight: bold; border-top: 1px solid #334155; padding-top: 15px !important; }

        /* PERBAIKAN LOGO SEARCH AGAR SEJAJAR */
        .search-group {
            position: relative;
            width: 250px;
        }
        .search-group i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            z-index: 10;
        }
        .search-group .form-control {
            padding-left: 35px; /* Memberi ruang untuk icon di kiri */
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <div class="sidebar">
    <h4><i class="fa fa-book"></i> E Library</h4>
    <div class="text-center mb-3">
        <img src="perpus.jpeg" class="profile-img">
    </div>
    <a href="dashboard.php"><i class="fa-solid fa-house me-2"></i> Dashboard</a>
    <a href="data_buku.php" style="background:#334155;"><i class="fa-solid fa-book me-2"></i> Data Buku</a>
    <a href="data_anggota.php"><i class="fa-solid fa-users me-2"></i> Anggota</a>
    <a href="data_peminjaman.php"><i class="fa-solid fa-book-open me-2"></i> Peminjaman</a>
    <a href="data_pengembalian.php"><i class="fa-solid fa-square-check me-2"></i> Pengembalian</a>
    
    <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
        <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
    </a>
</div>

<div class="main">
    <h3 class="mb-4">📚 Manajemen Data Buku</h3>

    <button class="btn btn-tambah mb-3" data-bs-toggle="modal" data-bs-target="#tambah">
        <i class="fa fa-plus"></i> Tambah Data
    </button>
    <a href="print_buku.php" class="btn btn-secondary mb-3"><i class="fa fa-print"></i> Print</a>

    <div class="card">
        <div class="card-header bg-white pt-3 pb-3 border-0 d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Daftar Buku</h5>
            <div class="search-group">
                <i class="fa fa-search"></i>
                <input type="text" class="form-control" placeholder="Cari data buku..." id="searchInput">
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Judul</th>
                            <th>Pengarang</th>
                            <th>Penerbit</th>
                            <th>Tahun</th>
                            <th>Jumlah</th>
                            <th>Lokasi</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $q = mysqli_query($conn, "SELECT * FROM tb_buku ORDER BY id_buku DESC");
                    while($d = mysqli_fetch_assoc($q)){
                    ?>
                        <tr>
                            <td><?= $d['id_buku'] ?></td>
                            <td><?= $d['judul'] ?></td>
                            <td><?= $d['pengarang'] ?></td>
                            <td><?= $d['penerbit'] ?></td>
                            <td><?= $d['tahun_terbit'] ?></td>
                            <td><?= $d['jumlah_buku'] ?></td>
                            <td><?= $d['lokasi'] ?></td>
                            <td>
                                <button class="btn btn-edit btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $d['id_buku'] ?>">Edit</button>
                                <a href="?delete=<?= $d['id_buku'] ?>" class="btn btn-hapus btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                            </td>
                        </tr>

                        <div class="modal fade" id="edit<?= $d['id_buku'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST">
                                        <div class="modal-header"><h5>Edit Buku</h5></div>
                                        <div class="modal-body">
                                            <input type="hidden" name="id_buku" value="<?= $d['id_buku'] ?>">
                                            <label class="small text-muted">Judul Buku</label>
                                            <input class="form-control mb-2" name="judul" value="<?= $d['judul'] ?>" required>
                                            <label class="small text-muted">Pengarang</label>
                                            <input class="form-control mb-2" name="pengarang" value="<?= $d['pengarang'] ?>" required>
                                            <label class="small text-muted">Penerbit</label>
                                            <input class="form-control mb-2" name="penerbit" value="<?= $d['penerbit'] ?>" required>
                                            <label class="small text-muted">Tahun Terbit</label>
                                            <input class="form-control mb-2" name="tahun_terbit" value="<?= $d['tahun_terbit'] ?>" required>
                                            <label class="small text-muted">Jumlah</label>
                                            <input class="form-control mb-2" name="jumlah_buku" value="<?= $d['jumlah_buku'] ?>" required>
                                            <label class="small text-muted">Lokasi Rak</label>
                                            <input class="form-control mb-2" name="lokasi" value="<?= $d['lokasi'] ?>" required>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-edit" name="update">Simpan Perubahan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="tambah" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header"><h5>Tambah Buku Baru</h5></div>
                <div class="modal-body">
                    <input class="form-control mb-2" name="judul" placeholder="Judul Buku" required>
                    <input class="form-control mb-2" name="pengarang" placeholder="Pengarang" required>
                    <input class="form-control mb-2" name="penerbit" placeholder="Penerbit" required>
                    <input class="form-control mb-2" name="tahun_terbit" placeholder="Tahun Terbit" required>
                    <input class="form-control mb-2" name="jumlah_buku" placeholder="Jumlah Buku" required>
                    <input class="form-control mb-2" name="lokasi" placeholder="Lokasi Rak" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-tambah" name="create">Simpan Buku</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('searchInput').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const rows = document.querySelectorAll('.table tbody tr');
        
        rows.forEach(row => {
            const title = row.cells[1].textContent.toLowerCase();
            const author = row.cells[2].textContent.toLowerCase();
            const publisher = row.cells[3].textContent.toLowerCase();
            
            if (title.includes(searchTerm) || author.includes(searchTerm) || publisher.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>    
</body>
</html><?php
include "koneksi.php";

// ================= INSERT =================
if (isset($_POST['create'])) {
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $jumlah = $_POST['jumlah_buku'];
    $lokasi = $_POST['lokasi'];

    $query = mysqli_query($conn, "INSERT INTO tb_buku 
    (judul, pengarang, penerbit, tahun_terbit, jumlah_buku, lokasi)
    VALUES ('$judul', '$pengarang', '$penerbit', '$tahun', '$jumlah', '$lokasi')");

    if($query) {
        // Notifikasi Tambah Berhasil
        echo "<script>alert('Buku Berhasil Ditambahkan!'); window.location='data_buku.php';</script>";
    }
}

// ================= UPDATE =================
if (isset($_POST['update'])) {
    $id = $_POST['id_buku'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $jumlah = $_POST['jumlah_buku'];
    $lokasi = $_POST['lokasi'];

    $query = mysqli_query($conn, "UPDATE tb_buku SET
        judul='$judul',
        pengarang='$pengarang',
        penerbit='$penerbit',
        tahun_terbit='$tahun',
        jumlah_buku='$jumlah',
        lokasi='$lokasi'
        WHERE id_buku='$id'");

    if($query) {
        // NOTIFIKASI UPDATE BERHASIL (DITARUH DISINI AGAR AMAN)
        echo "<script>alert('Update Berhasil!'); window.location='data_buku.php';</script>";
    }
}

// ================= DELETE =================
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $cek_peminjaman = mysqli_query($conn, "SELECT * FROM tb_peminjaman WHERE id_buku = '$id'");

    if (mysqli_num_rows($cek_peminjaman) > 0) {
        echo "<script>
                alert('Gagal menghapus! Buku ini masih terdaftar dalam data peminjaman.');
                window.location='data_buku.php';
              </script>";
    } else {
        $query = mysqli_query($conn, "DELETE FROM tb_buku WHERE id_buku='$id'");
        
        if($query) {
            echo "<script>
                    alert('Data buku berhasil dihapus.');
                    window.location='data_buku.php';
                  </script>";
        }
    }
}
?>

