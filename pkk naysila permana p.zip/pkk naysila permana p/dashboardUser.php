<?php
session_start();
include 'koneksi.php';

// DATA BUKU - Link foto asli tidak diubah
$semua_buku = [
    'Teknologi' => [
        ['judul' => 'Belajar JavaScript', 'foto' => 'https://www.w3schools.com/whatis/img_js.png'],
    ],
    'Sains' => [
        ['judul' => 'Fisika Kuantum', 'foto' => 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400'],
        ['judul' => 'Astronomi Dasar', 'foto' => 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400']
    ],
    'Novel' => [
        ['judul' => 'Laskar Pelangi', 'foto' => 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400'],
        ['judul' => 'Bumi Manusia', 'foto' => 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400']
    ],
    'Sejarah' => [
        ['judul' => 'Sejarah Dunia', 'foto' => 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=400']
    ]
];

// PROSES LOGIKA PHP
$notif = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id_user = trim($_POST['id_user'] ?? '');
    $judul_buku = $_POST['judul_buku'] ?? '';
    $tanggal = $_POST['tanggal'] ?? '';

    // Ambil nama berdasarkan ID yang dipilih langsung dari tb_user
    $nama_peminjam = "";
    if (!empty($id_user)) {
        $queryUser = mysqli_query($conn, "SELECT username FROM tb_user WHERE id = '$id_user' AND role = 'user'");
        if ($dataUser = mysqli_fetch_assoc($queryUser)) {
            $nama_peminjam = $dataUser['username'];
        }
    }

    if ($action === 'pinjam') {
        if (!empty($id_user) && !empty($nama_peminjam) && !empty($judul_buku)) {
            $_SESSION['peminjaman'][] = [
                'id_user' => $id_user,
                'nama' => $nama_peminjam,
                'buku' => $judul_buku,
                'tanggal' => $tanggal,
                'status' => 'Dipinjam'
            ];
            $notif = "<div class='alert alert-success m-0 mb-3' id='notifArea'>🎉 Buku <b>'$judul_buku'</b> berhasil dipinjamkan ke $nama_peminjam!</div>";
        } else {
            $notif = "<div class='alert alert-danger m-0 mb-3' id='notifArea'>⚠️ Mohon Pilih User dan Pilih Buku terlebih dahulu!</div>";
        }
    } elseif ($action === 'kembali') {
        $found = false;
        
        // Cari data buku yang paling terakhir dipinjam dan statusnya masih 'Dipinjam'
        for ($i = count($_SESSION['peminjaman']) - 1; $i >= 0; $i--) {
            if ($_SESSION['peminjaman'][$i]['status'] === 'Dipinjam') {
                $judul_buku_diubah = $_SESSION['peminjaman'][$i]['buku'];
                
                $_SESSION['peminjaman'][$i]['status'] = 'Dikembalikan';
                $_SESSION['peminjaman'][$i]['tanggal'] = $tanggal; 
                
                $found = true;
                $judul_buku = $judul_buku_diubah; 
                break; 
            }
        }
        
        if ($found) {
            $notif = "<div class='alert alert-info m-0 mb-3' id='notifArea'>🔄 Buku <b>'$judul_buku'</b> berhasil dikembalikan! Status di tabel diperbarui.</div>";
        } else {
            $notif = "<div class='alert alert-warning m-0 mb-3' id='notifArea'>⚠️ Tidak ada data peminjaman aktif (status Dipinjam) yang bisa dikembalikan.</div>";
        }
    }
}

// Ambil semua data user yang rolenya cuma 'user' untuk dimasukkan ke dropdown select
$querySiswa = mysqli_query($conn, "SELECT id, username FROM tb_user WHERE role = 'user'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Library Naysila</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; }
        .main-wrapper { display: flex; min-height: 100vh; }
        
        /* Sidebar Kiri Tetap */
        .sidebar { width: 260px; height: 100vh; position: fixed; top: 0; left: 0; background: #1e293b; color: white; padding: 25px 20px; z-index: 100; box-shadow: 4px 0 10px rgba(0,0,0,0.1); }
        .sidebar h4 { font-weight: bold; font-size: 20px; margin-bottom: 25px; color: #fff; text-shadow: 1px 1px 2px rgba(0,0,0,0.3); }
        .profile-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #3b82f6; }
        
        /* Menu Item Sidebar */
        .sidebar-item { padding: 12px 15px; cursor: pointer; border-radius: 10px; margin-bottom: 8px; background: #2d3748; transition: all 0.3s ease; color: #cbd5e1; font-weight: 500; border: none; }
        .sidebar-item:hover { background: #334155; color: #fff; padding-left: 20px; }
        .sidebar-item.active { background: #0d6efd; color: white; font-weight: bold; box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3); }

        /* Area Konten Kanan */
        .content-area { flex: 1; margin-left: 260px; display: flex; flex-direction: column; }
        .header-bg { background: #2c3e50; color: white; padding: 20px 40px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header-bg h2 { margin: 0; font-size: 22px; font-weight: 700; letter-spacing: 0.5px; }
        .logout-btn { background: #ff5e5e; color: white; padding: 8px 18px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 14px; display: flex; align-items: center; transition: 0.2s; }
        .logout-btn:hover { background: #e04a4a; color: white; box-shadow: 0 4px 10px rgba(255, 94, 94, 0.3); }
        
        .inner-container { padding: 30px; }
        .box-putih { background: white; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
        
        /* Card Katalog Buku */
        .book-card { border: 1px solid #e2e8f0; border-radius: 12px; padding: 15px; text-align: center; background: white; height: 100%; transition: all 0.3s ease; }
        .book-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
        .book-card img { width: 100%; height: 200px; object-fit: contain; background: #fafafa; border-radius: 8px; margin-bottom: 15px; padding: 10px; }
        .book-title { font-weight: 600; font-size: 15px; color: #1e293b; display: block; margin-bottom: 12px; height: 44px; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
    </style>
</head>
<body>

<div class="main-wrapper">
    
    <div class="sidebar">
        <h4><i class="fa fa-book me-2 text-primary"></i>E-Library Panel</h4>
        <div class="text-center mb-4">
            <img src="perpus.jpeg" class="profile-img" onerror="this.src='https://cdn-icons-png.flaticon.com/512/149/149071.png'">
        </div>
        
        <h6 class="text-uppercase text-muted fw-bold small mb-3 tracking-wider">Kategori Buku</h6>
        <div id="kat-list">
            <div class="sidebar-item active" onclick="pilihKategori('Teknologi', this)">📟 Teknologi</div>
            <div class="sidebar-item" onclick="pilihKategori('Sains', this)">🔬 Sains</div>
            <div class="sidebar-item" onclick="pilihKategori('Novel', this)">📚 Novel</div>
            <div class="sidebar-item" onclick="pilihKategori('Sejarah', this)">⏳ Sejarah</div>
        </div>
    </div>

    <div class="content-area">
        
        <div class="header-bg">
            <h2>📚 E-LIBRARY NAYSILA</h2>
            <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
                <i class="fa-solid fa-right-from-bracket me-2"></i> Keluar Aplikasi
            </a>
        </div>

        <div class="inner-container">
            <?= $notif ?>

            <div class="box-putih">
                <h4 class="mb-4 text-primary fw-bold"><i class="fa-solid fa-feather-alt me-2"></i>Peminjaman Aktif</h4>
                
                <form id="formPeminjaman" method="POST" action="" class="row g-2 align-items-center">
                    <input type="hidden" name="action" id="formAction" value="pinjam">
                    
                    <div class="col-md-4">
                        <select name="id_user" id="idUser" class="form-select" required>
                            <option selected disabled value="">-- Pilih Peminjam (ID - Nama) --</option>
                            <?php while($user = mysqli_fetch_assoc($querySiswa)): ?>
                                <option value="<?= $user['id'] ?>">ID: <?= $user['id'] ?> - <?= htmlspecialchars($user['username']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <select name="judul_buku" id="inputBuku" class="form-select" required>
                            <option selected disabled value="">-- Pilih Judul Buku --</option>
                            <option value="Belajar JavaScript">Belajar JavaScript</option>
                            <option value="Fisika Kuantum">Fisika Kuantum</option>
                            <option value="Astronomi Dasar">Astronomi Dasar</option>
                            <option value="Laskar Pelangi">Laskar Pelangi</option>
                            <option value="Bumi Manusia">Bumi Manusia</option>
                            <option value="Sejarah Dunia">Sejarah Dunia</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-1 d-flex gap-1">
                        <button type="submit" onclick="setAction('pinjam')" class="btn btn-primary w-70 fw-bold">Pinjam</button>
                        <button type="submit" onclick="setAction('kembali')" class="btn btn-success w-70 fw-bold">Kembali</button>
                    </div>
                </form>
            </div>

            <div class="box-putih">
                <h4 id="judulKat" class="fw-bold text-dark border-bottom pb-2">Daftar Buku: Teknologi</h4>
                <div id="areaBuku" class="row g-4 mt-1"></div>
            </div>

            <div class="box-putih" id="tabelRiwayat">
                <h4 class="mb-3 text-secondary fw-bold"><i class="fa-solid fa-clock-history me-2"></i>Riwayat & Lembar Peminjaman</h4>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID User</th>
                                <th>Nama Peminjam</th>
                                <th>Judul Buku</th>
                                <th>Tanggal Aksi</th>
                                <th>Status peminjaman</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($_SESSION['peminjaman'])): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">Belum ada riwayat transaksi peminjaman buku.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach (array_reverse($_SESSION['peminjaman']) as $p): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($p['id_user']) ?></td>
                                        <td><?= htmlspecialchars($p['nama']) ?></td>
                                        <td><strong><?= htmlspecialchars($p['buku']) ?></strong></td>
                                        <td><?= date('d-m-Y', strtotime($p['tanggal'])) ?></td>
                                        <td>
                                            <?php if ($p['status'] === 'Dipinjam'): ?>
                                                <span class="badge bg-warning text-dark px-3 py-2"><i class="fa-solid fa-book-reader me-1"></i> Dipinjam</span>
                                            <?php else: ?>
                                                <span class="badge bg-success px-3 py-2"><i class="fa-solid fa-check-circle me-1"></i> Selesai</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

    <script>
        const dataBuku = <?= json_encode($semua_buku) ?>;

        function setAction(actionType) {
            document.getElementById('formAction').value = actionType;
            const idInput = document.getElementById('idUser');
            const bukuSelect = document.getElementById('inputBuku');

            if (actionType === 'kembali') {
                idInput.removeAttribute('required');
                bukuSelect.removeAttribute('required');

                if(idInput.value === "") idInput.selectedIndex = 1;
                if(bukuSelect.value === "") bukuSelect.selectedIndex = 1; 
            } else {
                idInput.setAttribute('required', 'required');
                bukuSelect.setAttribute('required', 'required');
            }
        }

        function pilihKategori(kat, el) {
            document.querySelectorAll('.sidebar-item').forEach(i => i.classList.remove('active'));
            el.classList.add('active');
            document.getElementById('judulKat').innerText = "Daftar Buku Kategori: " + kat;

            const area = document.getElementById('areaBuku');
            area.innerHTML = '';
            
            if(dataBuku[kat]) {
                dataBuku[kat].forEach(b => {
                    area.innerHTML += `
                        <div class="col-md-4">
                            <div class="book-card shadow-sm">
                                <img src="${b.foto}" alt="${b.judul}" onerror="this.src='https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400'">
                                <span class="book-title">${b.judul}</span>
                                <button type="button" onclick="isiKeForm('${b.judul}')" class="btn btn-outline-primary btn-sm w-100 fw-bold"><i class="fa-solid fa-plus me-1"></i> Pilih Buku</button>
                            </div>
                        </div>`;
                });
            }
        }

        function isiKeForm(judul) {
            document.getElementById('inputBuku').value = judul;
            window.scrollTo({top: 0, behavior: 'smooth'});
        }

        window.onload = () => { 
            pilihKategori('Teknologi', document.querySelector('.sidebar-item')); 
            if(document.getElementById('notifArea')) {
                document.getElementById('tabelRiwayat').scrollIntoView({ behavior: 'smooth' });
            }
        };
    </script>
</body>
</html>