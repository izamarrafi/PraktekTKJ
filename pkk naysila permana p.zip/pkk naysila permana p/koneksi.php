<?php
$conn = mysqli_connect( "localhost", "root", "", "db_pkk_library");
  if (!$conn) {
    die("connection failed: " . mysqli_connect_error());
  }