<?php
include "koneksi.php";

// --- PROSES TAMBAH DATA (SUDAH DIPERBAIKI SINKRON DENGAN DATABASE) ---
if (isset($_POST['create'])) {
    $id_anggota = mysqli_real_escape_string($conn, $_POST['id_anggota']);
    $id_buku    = mysqli_real_escape_string($conn, $_POST['id_buku']);
    $tanggal    = mysqli_real_escape_string($conn, $_POST['tanggal']);
    
    // Otomatis hitung batas kembali (+7 hari dari tanggal pinjam)
    $tanggal_kembali = date('Y-m-d', strtotime('+7 days', strtotime($tanggal)));

    // Kolom 'id' dihilangkan dari INSERT karena Auto Increment, dan kolom denda dibuang murni
    $query_insert = "INSERT INTO tb_peminjaman (id_buku, id_anggota, tanggal, tanggal_kembali, status) 
                     VALUES ('$id_buku', '$id_anggota', '$tanggal', '$tanggal_kembali', 'dipinjam')";
                     
    if (mysqli_query($conn, $query_insert)) {
        echo "<script>window.location='data_peminjaman.php';</script>";
    } else {
        echo "Error Tambah Data: " . mysqli_error($conn);
        exit();
    }
}

// --- PROSES KEMBALIKAN (LOGIKA HITUNG DENDA OTOMATIS & DIKUNCI MAKSIMAL) ---
if (isset($_GET['kembalikan'])) {
    $id = mysqli_real_escape_string($conn, $_GET['kembalikan']);
    
    // 1. Ambil info batas tanggal kembali dari data peminjaman aktif
    $cek_pinjam = mysqli_query($conn, "SELECT tanggal, tanggal_kembali FROM tb_peminjaman WHERE id='$id'");
    $data_pinjam = mysqli_fetch_assoc($cek_pinjam);
    
    if ($data_pinjam) {
        $batas_kembali = $data_pinjam['tanggal_kembali'];
        $hari_ini      = date('Y-m-d'); // Tanggal otomatis hari ini saat diklik
        
        $tarif_denda   = 1000;       // Tarif denda per hari jika terlambat
        $maks_denda    = 10000;      // NOMINAL DENDA MAKSIMAL (Mentok di Rp 10.000)
        $denda         = 0;
        $selisih_hari  = 0; 
        
        // 2. Hitung selisih jika tanggal hari ini melewati batas waktu seharusnya
        if (strtotime($hari_ini) > strtotime($batas_kembali)) {
            $selisih_detik = strtotime($hari_ini) - strtotime($batas_kembali);
            $selisih_hari  = floor($selisih_detik / (60 * 60 * 24));
            $denda_kotor   = $selisih_hari * $tarif_denda;
            
            // Jika denda melebihi batas, kunci di Rp 10.000
            if ($denda_kotor > $maks_denda) {
                $denda = $maks_denda;
            } else {
                $denda = $denda_kotor;
            }
        }
        
        // 3. Pindahkan data ke tb_pengembalian sesuai kolom di database kamu (nama, judul, tanggal_pinjam, tanggal_kembali, status, denda)
        $query_pindah = "INSERT INTO tb_pengembalian (nama, judul, tanggal_pinjam, tanggal_kembali, status, denda) 
                         SELECT a.nama, b.judul, p.tanggal, p.tanggal_kembali, 'dikembalikan', '$denda'
                         FROM tb_peminjaman p
                         JOIN tb_anggota a ON p.id_anggota = a.id 
                         JOIN tb_buku b ON p.id_buku = b.id_buku 
                         WHERE p.id='$id'";
        
        if (mysqli_query($conn, $query_pindah)) {
            // Hapus data dari daftar pinjam aktif karena sudah kembali
            mysqli_query($conn, "DELETE FROM tb_peminjaman WHERE id='$id' LIMIT 1");
            
            // Pop up notifikasi status pengembalian
            if ($denda > 0) {
                echo "<script>alert('Buku telah dikembalikan! Terlambat " . $selisih_hari . " hari. Denda dikunci maksimal: Rp " . number_format($denda, 0, ',', '.') . "'); window.location='data_peminjaman.php';</script>";
            } else {
                echo "<script>alert('Buku telah dikembalikan tepat waktu! (Bebas Denda)'); window.location='data_peminjaman.php';</script>";
            }
        } else {
            echo "Error SQL: " . mysqli_error($conn);
            exit();
        }
    }
}

// --- PROSES HAPUS ---
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    mysqli_query($conn, "DELETE FROM tb_peminjaman WHERE id='$id'");
    echo "<script>alert('Data peminjaman berhasil dihapus.'); window.location='data_peminjaman.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Peminjaman Aktif</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { margin: 0; font-family: 'Poppins', sans-serif; background: #f4f6f9; }
        .sidebar { width: 250px; height: 100vh; position: fixed; background: #1e293b; color: white; padding: 20px; z-index: 1000; }
        .sidebar a { display: block; color: #cbd5f5; padding: 10px; border-radius: 10px; text-decoration: none; margin-bottom: 5px; }
        .sidebar a:hover { background: #334155; color: white; }
        .profile-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #4f46e5; }
        .main { margin-left: 250px; padding: 30px; min-height: 100vh; }
        .card { border-radius: 15px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); border: none; }
        .table thead { background: #6366f1; color: white; }
        .logout-btn { color: #ff6b6b !important; margin-top: auto; font-weight: bold; border-top: 1px solid #334155; padding-top: 15px !important; }
        .search-container { max-width: 300px; }
        .search-group { position: relative; }
        .search-group i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        .search-group input { padding-left: 35px; border-radius: 10px; border: 1px solid #e2e8f0; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h4><i class="fa fa-book"></i> E Library</h4>
        <div class="text-center mb-3">
            <img src="perpus.jpeg" class="profile-img" alt="Profile">
        </div>
        <a href="dashboard.php"><i class="fa-solid fa-house me-2"></i> Dashboard</a>
        <a href="data_buku.php"><i class="fa-solid fa-book me-2"></i> Data Buku</a>
        <a href="data_anggota.php"><i class="fa-solid fa-users me-2"></i> Anggota</a>
        <a href="data_peminjaman.php" style="background:#334155;"><i class="fa-solid fa-book-open me-2"></i> Peminjaman</a>
        <a href="data_pengembalian.php"><i class="fa-solid fa-square-check me-2"></i> Pengembalian</a>
        <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
            <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
        </a>
    </div>

    <div class="main">
        <h3>📖 Peminjaman Aktif</h3>
        
        <div class="card mb-3">
            <div class="card-body">
                <form method="POST" class="row g-2">
                    <div class="col-md-3">
                        <select name="id_anggota" class="form-select" required>
                            <option value="">-- Pilih Anggota --</option>
                            <?php
                            $a = mysqli_query($conn, "SELECT * FROM tb_anggota");
                            while ($r = mysqli_fetch_assoc($a)) echo "<option value='" . $r['id'] . "'>" . $r['nama'] . "</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="id_buku" class="form-select" required>
                            <option value="">-- Pilih Buku --</option>
                            <?php
                            $b = mysqli_query($conn, "SELECT * FROM tb_buku");
                            while ($r = mysqli_fetch_assoc($b)) echo "<option value='" . $r['id_buku'] . "'>" . $r['judul'] . "</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3"><input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
                    <div class="col-md-3"><button class="btn btn-primary w-100" name="create">Pinjamkan</button></div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-white pt-3 pb-0 border-0 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Daftar Transaksi</h5>
                <div class="search-container">
                    <div class="search-group">
                        <i class="fa fa-search"></i>
                        <input type="text" class="form-control" placeholder="Cari data..." id="searchInput">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="borrowTable">
                        <thead>
                            <tr>
                                <th>Anggota</th>
                                <th>Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Batas Kembali</th>
                                <th>Status</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $q = mysqli_query($conn, "SELECT tb_peminjaman.*, tb_anggota.nama, tb_buku.judul 
                                                FROM tb_peminjaman 
                                                JOIN tb_anggota ON tb_peminjaman.id_anggota=tb_anggota.id 
                                                JOIN tb_buku ON tb_peminjaman.id_buku=tb_buku.id_buku 
                                                WHERE status='dipinjam' ORDER BY id DESC");
                            while ($d = mysqli_fetch_assoc($q)) {
                            ?>
                                <tr>
                                    <td><b><?= htmlspecialchars($d['nama']) ?></b></td>
                                    <td><?= htmlspecialchars($d['judul']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($d['tanggal'])) ?></td>
                                    <td><span class="text-danger fw-bold"><?= date('d/m/Y', strtotime($d['tanggal_kembali'])) ?></span></td>
                                    <td><span class="badge bg-warning text-dark">Dipinjam</span></td>
                                    <td class="text-center">
                                        <a href="?kembalikan=<?= $d['id'] ?>" class="btn btn-success btn-sm me-1" onclick="return confirm('Apakah buku ini benar-benar dikembalikan?')">
                                            <i class="fa fa-undo"></i> Kembalikan
                                        </a>
                                        <a href="?delete=<?= $d['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data?')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('searchInput').addEventListener('input', function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelector('#borrowTable tbody').rows;
            for (let i = 0; i < rows.length; i++) {
                let text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? '' : 'none';
            }
        });
    </script>
</body>
</html>