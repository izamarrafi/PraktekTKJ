<?php 
session_start();
include 'koneksi.php';

/**
 * 1. CEK SESSION (ANTI-LOOP)
 * Jika user sudah login, mereka tidak boleh mengakses halaman login lagi.
 * Ini untuk mencegah error "localhost sering mengalihkan anda".
 */
if (isset($_SESSION['status']) && $_SESSION['status'] == "login") {
    if ($_SESSION['role'] == "admin") {
        header("location:dashboard.php");
    } else {
        header("location:dashboardUser.php");
    }
    exit(); 
}

/**
 * 2. PROSES LOGIN
 */
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Query mencari user
    $query = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($query);

    if ($cek > 0) {
        $data = mysqli_fetch_assoc($query);

        // Simpan data ke session
        $_SESSION['username'] = $username;
        $_SESSION['nama']     = $data['nama_lengkap'];
        $_SESSION['role']     = $data['role']; 
        $_SESSION['status']   = "login";

        // Redirect sesuai role
        if ($data['role'] == "admin") {
            header("location:dashboard.php");
        } else if ($data['role'] == "user") {
            header("location:dashboardUser.php");
        }
        exit(); // Wajib ada exit agar tidak looping
    } else {
        // Jika gagal
        header("location:login.php?pesan=gagal");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Library - Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { 
            height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            background: linear-gradient(135deg, #eaf2ff, #f8fbff); 
            overflow: hidden; 
            position: relative; 
        }

        /* background aesthetic shapes */
        .shape1 { position: absolute; width: 320px; height: 320px; background: #bcd6ff; border-radius: 50%; top: -90px; left: -90px; filter: blur(50px); opacity: 0.7; }
        .shape2 { position: absolute; width: 260px; height: 260px; background: #dbe9ff; border-radius: 50%; bottom: -80px; right: -80px; filter: blur(50px); }

        /* glass card container */
        .container { 
            width: 900px; 
            height: 520px; 
            display: flex; 
            border-radius: 25px; 
            background: rgba(255, 255, 255, 0.65); 
            backdrop-filter: blur(14px); 
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.08); 
            overflow: hidden; 
            position: relative; 
            z-index: 1; 
            animation: fade 0.8s ease; 
        }

        @keyframes fade { 
            from { opacity: 0; transform: translateY(30px); } 
            to { opacity: 1; transform: translateY(0); } 
        }

        /* bagian kiri (Visual) */
        .left { 
            width: 50%; 
            background: linear-gradient(160deg, #8fbaff, #cfe2ff); 
            display: flex; 
            flex-direction: column; 
            justify-content: center; 
            align-items: center; 
            text-align: center; 
            padding: 40px; 
        }
        .left img { 
            width: 200px; 
            margin-bottom: 20px; 
            animation: float 4s ease-in-out infinite; 
        }
        @keyframes float { 
            0%, 100% { transform: translateY(0); } 
            50% { transform: translateY(-12px); } 
        }
        .left h1 { font-size: 36px; color: #2d3a4b; }
        .left p { font-size: 14px; color: #4f5d75; }

        /* bagian kanan (Form) */
        .right { 
            width: 50%; 
            padding: 60px; 
            display: flex; 
            flex-direction: column; 
            justify-content: center; 
        }
        .right h2 { font-size: 26px; margin-bottom: 6px; color: #2d3a4b; }
        .sub { font-size: 13px; color: #8a94a6; margin-bottom: 25px; }

        input { 
            width: 100%; 
            padding: 14px; 
            border-radius: 12px; 
            border: 1px solid #e6edf7; 
            margin-bottom: 15px; 
            background: rgba(255, 255, 255, 0.8); 
            transition: 0.3s; 
            outline: none; 
        }
        input:focus { border: 1px solid #7eaaff; background: white; }

        button { 
            width: 100%; 
            padding: 14px; 
            border: none; 
            border-radius: 12px; 
            background: linear-gradient(90deg, #7eaaff, #a9caff); 
            color: white; 
            font-size: 15px; 
            cursor: pointer; 
            transition: 0.25s; 
            font-weight: 500; 
        }
        button:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 10px 25px rgba(126, 170, 255, 0.4); 
        }

        .footer { margin-top: 18px; font-size: 12px; color: #9aa6b6; text-align: center; }
        
        .error-msg { 
            background: #ffe5e5; 
            color: #d9534f; 
            padding: 10px; 
            border-radius: 8px; 
            font-size: 12px; 
            margin-bottom: 15px; 
            text-align: center; 
            border: 1px solid #f5c6cb; 
        }
    </style>
</head>
<body>

<div class="shape1"></div>
<div class="shape2"></div>

<div class="container">
    <div class="left">
        <img src="https://cdn-icons-png.flaticon.com/512/2702/2702134.png" alt="Logo">
        <h1>E-Library</h1>
        <p>Sistem Informasi Perpustakaan</p>
    </div>

    <div class="right">
        <h2>Welcome</h2>
        <div class="sub">Masuk untuk mengelola perpustakaan</div>

        <?php if(isset($_GET['pesan']) && $_GET['pesan'] == "gagal"): ?>
            <div class="error-msg">Username atau Password salah!</div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Login</button>
        </form>

        <div class="footer">
            Library Management System &copy; 2026
        </div>
    </div>
</div>

</body>
</html>