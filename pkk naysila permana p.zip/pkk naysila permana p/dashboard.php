<?php
include "koneksi.php";
session_start();
// Proteksi: Jika bukan admin, tendang ke login atau dashboard user
if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin"){
    header("location:login.php?pesan=belum_login");
    exit();
}


// 1. Hitung Total Buku
$q_buku = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_buku");
$jumlah_buku = mysqli_fetch_assoc($q_buku)['total'];

// 2. Hitung Total Anggota
$q_anggota = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_anggota");
$jumlah_anggota = mysqli_fetch_assoc($q_anggota)['total'];

// 3. Hitung yang Sedang Dipinjam (Status harus 'Dipinjam')
$q_pinjam = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_peminjaman WHERE status='dipinjam'");
$dipinjam = mysqli_fetch_assoc($q_pinjam)['total'];

// 4. Hitung yang Sudah Kembali (Status harus 'Kembali' atau 'Dikembalikan')
$q_kembali = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_pengembalian WHERE status='dikembalikan' OR status='kembali'");
$kembali = mysqli_fetch_assoc($q_kembali)['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>E-Library Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { margin: 0; font-family: 'Poppins', sans-serif; background: #f4f6f9; }
        .sidebar { width: 250px; height: 100vh; position: fixed; background: #1e293b; color: white; padding: 20px; display: flex; flex-direction: column; }
        .sidebar a { display: block; color: #cbd5f5; padding: 10px; border-radius: 10px; text-decoration: none; margin-bottom: 5px; transition: 0.3s; }
        .sidebar a:hover { background: #334155; color: white; }
        .profile-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #4f46e5; }
        .main { margin-left: 260px; padding: 20px; }
        
        /* Style Tombol Logout */
        .logout-btn { color: #ff6b6b !important; margin-top: auto; font-weight: bold; border-top: 1px solid #334155; padding-top: 15px !important; }
        .logout-btn:hover { background: #452a2a !important; color: #ff8e8e !important; }

        /* Card Box & Clickable Style */
        .card-box { 
            position: relative; /* Penting untuk stretched-link */
            border-radius: 20px; 
            padding: 25px; 
            text-align: center; 
            color: white; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.08); 
            transition: 0.3s; 
            cursor: pointer;
        }
        .card-box:hover { transform: translateY(-8px) scale(1.03); }
        .card1 { background: linear-gradient(135deg,#6366f1,#8b5cf6); } 
        .card2 { background: linear-gradient(135deg,#0ea5e9,#38bdf8); } 
        .card3 { background: linear-gradient(135deg,#f59e0b,#fcd34d); color: #333; } 
        .card4 { background: linear-gradient(135deg,#22c55e,#86efac); color: #333; } 
        .card-box i { font-size: 40px; margin-top: 15px; opacity: 0.7; }
        
        .table-box { background: white; padding: 20px; border-radius: 15px; margin-top: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
    </style>
</head>
<body>

<div class="sidebar">
    <h4><i class="fa fa-book"></i> E Library</h4>
    <div class="text-center mb-3">
        <img src="perpus.jpeg" class="profile-img">
    </div>
    
    <a href="dashboard.php" style="background:#334155;"><i class="fa-solid fa-house me-2"></i> Dashboard</a>
    <a href="data_buku.php"><i class="fa-solid fa-book me-2"></i> Data Buku</a>
    <a href="data_anggota.php"><i class="fa-solid fa-users me-2"></i> Anggota</a>
    <a href="data_peminjaman.php"><i class="fa-solid fa-book-open me-2"></i> Peminjaman</a>
    <a href="data_pengembalian.php"><i class="fa-solid fa-square-check me-2"></i> Pengembalian</a>
    
    <a href="logout.php" class="logout-btn" onclick="return confirm('Apakah anda yakin ingin keluar?')">
        <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
    </a>
</div>

<div class="main">
    <h3 class="mb-4">Dashboard</h3>

    <div class="row g-4">
        <!-- Card Total Buku -->
        <div class="col-md-3">
            <div class="card-box card1">
                <a href="data_buku.php" class="stretched-link"></a>
                <h4><?= $jumlah_buku ?></h4>
                <p class="mb-0">Total Buku</p>
                <i class="fa-solid fa-book"></i>
            </div>
        </div>

        <!-- Card Total Anggota -->
        <div class="col-md-3">
            <div class="card-box card2">
                <a href="data_anggota.php" class="stretched-link"></a>
                <h4><?= $jumlah_anggota ?></h4>
                <p class="mb-0">Total Anggota</p>
                <i class="fa-solid fa-users"></i>
            </div>
        </div>

        <!-- Card Sedang Dipinjam -->
        <div class="col-md-3">
            <div class="card-box card3">
                <a href="data_peminjaman.php" class="stretched-link"></a>
                <h4><?= $dipinjam ?></h4>
                <p class="mb-0">Sedang Dipinjam</p>
                <i class="fa-solid fa-book-open-reader"></i>
            </div>
        </div>

        <!-- Card Sudah Kembali -->
        <div class="col-md-3">
            <div class="card-box card4">
                <a href="data_pengembalian.php" class="stretched-link"></a>
                <h4><?= $kembali ?></h4>
                <p class="mb-0">Sudah Kembali</p>
                <i class="fa-solid fa-check"></i>
            </div>
        </div>
    </div>

    <div class="table-box">
        <h5 class="mb-3"><i class="fa fa-clock-rotate-left"></i> Peminjaman Terbaru</h5>
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Nama Anggota</th>
                    <th>Judul Buku</th>
                    <th>Tgl Pinjam</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query_tabel = "SELECT tb_peminjaman.*, tb_anggota.nama, tb_buku.judul 
                                FROM tb_peminjaman 
                                JOIN tb_anggota ON tb_peminjaman.id_anggota = tb_anggota.id 
                                JOIN tb_buku ON tb_peminjaman.id_buku = tb_buku.id_buku 
                                ORDER BY tb_peminjaman.id DESC LIMIT 5";
                $res = mysqli_query($conn, $query_tabel);
                
                while($row = mysqli_fetch_assoc($res)){
                ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['judul']) ?></td>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td>
                        <span class="badge <?= ($row['status']=='Dipinjam') ? 'bg-warning text-dark' : 'bg-success' ?>">
                            <?= $row['status'] ?>
                        </span>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="text-end">
            <a href="data_peminjaman.php" class="btn btn-sm btn-outline-primary">Lihat Semua →</a>
        </div>
    </div>
</div>

</body>
</html>